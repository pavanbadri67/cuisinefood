import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-menu-page',
  templateUrl: './menu-page.component.html',
  styleUrls: ['./menu-page.component.css']
})
export class MenuPageComponent implements OnInit {

  tiffinsDetails =[
    {
      itemname:"Dosa",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "50",
      quantity: 1,
    },
    {
      itemname:"Idly",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "30",
      quantity: 1
    },
    {
      itemname:"Chappathi",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "60",
      quantity: 1
    },
    {
      itemname:"Puri",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "45",
      quantity: 1
    },
    {
      itemname:"Vadda",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "40",
      quantity: 1
    },
    {
      itemname:"Upma",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "25",
      quantity: 1
    },
    {
      itemname:"Uthappa",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "45",
      quantity: 1
    },
    {
      itemname:"Bonda",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "45",
      quantity: 1
    }
  ]
  vegetarianDetails =[
    {
      itemname:"Veg-Biryani",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "139",
      quantity: 1
    },
    {
      itemname:"Panner Butter Masala",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "205",
      quantity: 1
    },
    {
      itemname:"Dal Makani",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "159",
      quantity: 1
    },
    {
      itemname:"Coconut Rice",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "110",
      quantity: 1
    },
    {
      itemname:"Veg-Pulao",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "179",
      quantity: 1
    },
    {
      itemname:"Thali",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "159",
      quantity: 1
    },
    {
      itemname:"Gutti Vankaya Kurra & Rice",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "89",
      quantity: 1
    },
    {
      itemname:"Bisi Belebath",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "169",
      quantity: 1
    },
  ]
  nonvegDetails=[
    {
      itemname:"Dum Briyani (single)",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "159",
      quantity: 1
    },
    {
      itemname:"Dum Briyani (family)",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "499",
      quantity: 1
    },
    {
      itemname:"Butter Chicken",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "229",
      quantity: 1
    },
    {
      itemname:"Gongura Chicken",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "199",
      quantity: 1
    },
    {
      itemname:"Mutton Briyani(single)",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "239",
      quantity: 1
    },
    {
      itemname:"Mutton Briyani(Family)",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "899",
      quantity: 1
    },
    {
      itemname:"Apollo Fish",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "389",
      quantity: 1
    },
    {
      itemname:"Chilli Chicken",
      type:"Veg",
      cuisine:"South India",
      availability:"Breakfast & Lunch",
      price: "199",
      quantity: 1
    },
  ]
  cartAddedItems:any = [];
  constructor(private cartService: CartService) { }

  ngOnInit(): void {}
  plus(i:any){
    if(this.tiffinsDetails[i].quantity !=10){
    this.tiffinsDetails[i].quantity = this.tiffinsDetails[i].quantity+1;
    }
  }
  minus(i:any){
    if(this.tiffinsDetails[i].quantity > 1){
      this.tiffinsDetails[i].quantity = this.tiffinsDetails[i].quantity-1;
    }
  }
  plus1(i:any){
    if(this.vegetarianDetails[i].quantity !=10){
    this.vegetarianDetails[i].quantity = this.vegetarianDetails[i].quantity+1;
    }
  }
  minus1(i:any){
    if(this.vegetarianDetails[i].quantity > 1){
      this.vegetarianDetails[i].quantity = this.vegetarianDetails[i].quantity-1;
    }
  }
  plus2(i:any){
    if(this.nonvegDetails[i].quantity !=10){
    this.nonvegDetails[i].quantity = this.nonvegDetails[i].quantity+1;
    }
  }
  minus2(i:any){
    if(this.nonvegDetails[i].quantity > 1){
      this.nonvegDetails[i].quantity = this.nonvegDetails[i].quantity-1;
    }
  }
  itemsCart:any =[]
  addItemsToCart(item:any){
    let date = new Date();
    item.date = date;
    this.cartAddedItems.push(item);
    // this.cartService.cartList.next(this.cartAddedItems);
    localStorage.setItem('localItem', JSON.stringify(this.cartAddedItems))


    
  }
}